# rsa_proj
a project for implementing rsa encrypting algorithm.

# showcase
![avatar](./showcase/2020013114584499.gif)

# Author
- BrianYi
